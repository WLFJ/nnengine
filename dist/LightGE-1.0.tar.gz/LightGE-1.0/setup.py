from distutils.core import setup

setup(
    name='LightGE',
    version='1.0',
    packages=['lightGE', 'LightGE.core', 'LightGE.data', 'LightGE.utils'],
    url='https://gitlab.com/l7829936101/nnengine'
)
